import { AboutPage } from './about'
import { HomePage } from './home'
import { LoginPage } from './login'
import { Rigistration } from './signup'


export {
    HomePage,
    AboutPage,
    LoginPage,
    Rigistration
}