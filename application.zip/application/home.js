import React, { Component } from 'react';
import { Text, View, Button } from 'react-native';

export class HomePage extends Component {
    render() {
        return (
            <View style={{ flex: 1 }}>
                <Text>
                    Welcome to Home page!
        </Text>
            </View>
        );
    }
}
