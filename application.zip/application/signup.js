import React, { Component } from 'react';
import firebase from 'firebase';

import { Container, Button, Content, Form, Item, Input, Label, Text } from 'native-base';

export class Rigistration extends Component {
    constructor(prop) {
        super(prop)
        this.state = {
            Username: "",
            email: "",
            password: ""
        }
    }

    createAccount(e) {
        console.log("Registration");
        // this.props.navigation.navigate("login");
        //         let db=firebase.database().ref('/').child("users")
        // db.set(this.state).then((result) => {
        //     console.log("Account Create Suuccessfully")
        //     this.props.navigation.navigate("login");
        // })
        firebase.auth().createUserWithEmailAndPassword(this.state.email, this.state.password)
            .then((r) => {
                let db = firebase.database().ref('/').child(`users/${r.uid}`)
                db.set(this.state).then((result) => {
                    console.log("Account Create Suuccessfully")
                    console.log(r.email);
                    this.props.navigation.navigate("login",{mail:this.state.email})
                })
            })
            .catch((error) => {
                var errorMessage = error.message;
                console.log(error)
            });
    }

    render() {
        return (
            <Container>
                <Content>
                    <Form>
                        <Item fixedLabel>
                            <Label>Username</Label>
                            <Input onChangeText={(e) => this.setState({ Username: e })} />
                        </Item>
                        <Item fixedLabel>
                            <Label>Email</Label>
                            <Input onChangeText={(email) => this.setState({ email })} />
                        </Item>
                        <Item fixedLabel last>
                            <Label>Password</Label>
                            <Input onChangeText={(e) => this.setState({ password: e })} />
                        </Item>
                    </Form>
                    <Button full info onPress={this.createAccount.bind(this)}><Text> Signup </Text></Button>
                </Content>
            </Container>
        );
    }
}
